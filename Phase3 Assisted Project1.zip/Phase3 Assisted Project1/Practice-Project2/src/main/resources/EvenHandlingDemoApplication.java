import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventHandlingDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(EventHandlingDemoApplication.class, args);
    }
}
