import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

@Component
public class EventPublisher {

    private final ApplicationEventPublisher eventPublisher;

    @Autowired
    public EventPublisher(ApplicationEventPublisher eventPublisher) {
        this.eventPublisher = eventPublisher;
    }

    public void publishDefaultEvent() {
        System.out.println("Publishing Default Event...");
        DefaultEvent event = new DefaultEvent(this);
        eventPublisher.publishEvent(event);
    }

    public void publishCustomEvent(String message) {
        System.out.println("Publishing Custom Event...");
        CustomEvent event = new CustomEvent(this, message);
        eventPublisher.publishEvent(event);
    }
}
