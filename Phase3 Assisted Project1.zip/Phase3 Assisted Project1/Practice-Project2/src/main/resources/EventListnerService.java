import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;

@Component
public class EventListenerService {

    @EventListener
    public void handleDefaultEvent(DefaultEvent event) {
        System.out.println("Default Event Handler: " + event);
    }

    @EventListener
    public void handleCustomEvent(CustomEvent event) {
        System.out.println("Custom Event Handler: " + event);
    }
}
