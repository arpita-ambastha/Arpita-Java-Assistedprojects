import org.springframework.context.ApplicationEvent;

public class DefaultEvent extends ApplicationEvent {

    public DefaultEvent(Object source) {
        super(source);
    }

    @Override
    public String toString() {
        return "DefaultEvent occurred.";
    }
}
