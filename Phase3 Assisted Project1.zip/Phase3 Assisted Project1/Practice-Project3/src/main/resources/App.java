import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class App {
    public static void main(String[] args) {
        try (AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(DatabaseConfig.class)) {
            UserDao userDao = context.getBean(UserDao.class);

            // Save a new user
            User newUser = new User();
            newUser.setName("John Doe");
            userDao.save(newUser);

            // Find user by ID
            User retrievedUser = userDao.findById(1);
            System.out.println("Retrieved user: " + retrievedUser.getName());

            // Update user
            retrievedUser.setName("Jane Smith");
            userDao.update(retrievedUser);

            // Get all users
            List<User> allUsers = userDao.findAll();
            System.out.println("All users:");
            for (User user : allUsers) {
                System.out.println(user.getName());
            }

            // Delete user
            userDao.delete(1);
        }
    }
}
