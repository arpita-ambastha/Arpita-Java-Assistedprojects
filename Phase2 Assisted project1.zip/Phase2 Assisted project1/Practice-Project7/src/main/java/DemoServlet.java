import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DemoServlet")
public class DemoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Check if the session ID is present in the URL
        String sessionId = request.getParameter("sessionId");

        // Generate a new session ID if not present
        if (sessionId == null) {
            sessionId = java.util.UUID.randomUUID().toString();
            String url = response.encodeURL(request.getContextPath() + "/DemoServlet?sessionId=" + sessionId);
            response.sendRedirect(url);
        }

        // Display the session ID
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Session Tracking with URL Rewrite</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Session ID: " + sessionId + "</h1>");
        out.println("</body>");
        out.println("</html>");
    }
}
