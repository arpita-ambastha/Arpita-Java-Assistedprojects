import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/DemoServlet")
public class DemoServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get the HTTP session object associated with the request
        HttpSession session = request.getSession();

        // Generate a new session ID if the session is new
        if (session.isNew()) {
            String sessionId = session.getId();
            System.out.println("New session created with ID: " + sessionId);
        }

        // Set session attribute
        session.setAttribute("username", "Arpita");

        // Display the session ID and username
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Session Tracking with HTTP Session</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Session ID: " + session.getId() + "</h1>");
        out.println("<h2>Username: " + session.getAttribute("username") + "</h2>");
        out.println("</body>");
        out.println("</html>");
    }
}
