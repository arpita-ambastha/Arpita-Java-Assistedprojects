import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Get the username and password from the request parameters
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Check if the username and password are valid
        if (isValidUser(username, password)) {
            // Create a new session or retrieve the existing session
            HttpSession session = request.getSession();

            // Set the authenticated user in the session
            session.setAttribute("username", username);

            // Redirect to the home page
            response.sendRedirect("home.jsp");
        } else {
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Login Failed</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Login Failed. Invalid username or password.</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    private boolean isValidUser(String username, String password) {
        // Validate the username and password against a user database or any other authentication mechanism
        // Return true if the credentials are valid, false otherwise
        // This is a dummy method for demonstration purposes
        return username.equals("admin") && password.equals("admin123");
    }
}
