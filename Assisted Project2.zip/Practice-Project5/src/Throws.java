class CustomException extends Exception {
    public CustomException(String message) {
        super(message);
    }
}

public class Throws {
    public static void main(String[] args) {
        try {
            divideNumbers(10, 0); // Calling a method that may throw an exception
        } catch (CustomException e) {
            System.out.println("Custom Exception caught: " + e.getMessage());
        } finally {
            System.out.println("Inside finally block.");
        }
    }

    public static void divideNumbers(int dividend, int divisor) throws CustomException {
        try {
            if (divisor == 0) {
                throw new CustomException("Divisor cannot be zero.");
            }
            int result = dividend / divisor;
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            throw new CustomException("ArithmeticException occurred: " + e.getMessage());
        }
    }
}