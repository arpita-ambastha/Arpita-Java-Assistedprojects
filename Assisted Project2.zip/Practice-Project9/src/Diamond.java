interface Animal {
    void eat();
}

interface Mammal extends Animal {
    void sleep();
}

interface Bird extends Animal {
    void fly();
}

class Bat implements Mammal, Bird {
    @Override
    public void eat() {
        System.out.println("Bat is eating");
    }

    @Override
    public void sleep() {
        System.out.println("Bat is sleeping");
    }

    @Override
    public void fly() {
        System.out.println("Bat is flying");
    }
}

public class Diamond {
    public static void main(String[] args) {
        Bat bat = new Bat();
        bat.eat();
        bat.sleep();
        bat.fly();
    }
}