import java.util.*;
class create_thread implements Runnable{  
public void run()
{  
System.out.println("thread is running...");  
}
public static void main(String args[]){  
create_thread m1=new create_thread();  
Thread t1 =new Thread(m1);   // Using the constructor Thread(Runnable r)  
t1.start();  
System.out.println("Main method executed by main thread");
 
}
}
class Test extends Thread 
{
    public void run()
    {
        System.out.println("Run method executed by child Thread");
    }
  

}  