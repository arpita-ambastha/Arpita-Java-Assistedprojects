
class Vehicle {
    private String brand;
    private int year;

    public Vehicle(String brand, int year) {
        this.brand = brand;
        this.year = year;
    }

    public String getBrand() {
        return brand;
    }

    public int getYear() {
        return year;
    }

    public void displayInfo() {
        System.out.println("Brand: " + brand);
        System.out.println("Year: " + year);
    }
}

// Derived class representing a car (inherits from Vehicle)
class Car extends Vehicle {
    private String model;

    public Car(String brand, String model, int year) {
        super(brand, year);
        this.model = model;
    }

    public String getModel() {
        return model;
    }

    @Override
    public void displayInfo() {
        System.out.println("Vehicle Type: Car");
        super.displayInfo();
        System.out.println("Model: " + model);
    }
}

// Derived class representing a motorcycle (inherits from Vehicle)
class Motorcycle extends Vehicle {
    private String type;

    public Motorcycle(String brand, String type, int year) {
        super(brand, year);
        this.type = type;
    }

    public String getType() {
        return type;
    }

    @Override
    public void displayInfo() {
        System.out.println("Vehicle Type: Motorcycle");
        super.displayInfo();
        System.out.println("Type: " + type);
    }
}

// Main class
public class Vehicles {
    public static void main(String[] args) {
        Car car = new Car("Toyota", "Corolla", 2020);
        Motorcycle motorcycle = new Motorcycle("Honda", "Sport", 2021);

        // Polymorphic behavior
        Vehicle vehicle1 = car;
        Vehicle vehicle2 = motorcycle;

        // Accessing object properties and calling methods
        System.out.println("Car Information:");
        car.displayInfo();
        System.out.println();

        System.out.println("Motorcycle Information:");
        motorcycle.displayInfo();
        System.out.println();

        // Accessing properties and calling methods using polymorphic references
        System.out.println("Vehicle 1 Information:");
        vehicle1.displayInfo();
        System.out.println();

        System.out.println("Vehicle 2 Information:");
        vehicle2.displayInfo();
    }
}
    
