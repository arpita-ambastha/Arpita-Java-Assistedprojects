import java.util.Arrays;

public class FourthSmallestElement {
    
    public static int findFourthSmallest(int[] arr) {
        if (arr == null || arr.length < 4) {
            throw new IllegalArgumentException("Input array should contain at least four elements");
        }
        
        Arrays.sort(arr); // Sort the array in ascending order
        
        return arr[3]; // Return the fourth element (index 3) since arrays are zero-based
    }
    
    public static void main(String[] args) {
        int[] numbers = {10, 7, 15, 3, 9, 2, 8, 11};
        int fourthSmallest = findFourthSmallest(numbers);
        
        System.out.println("The fourth smallest element is: " + fourthSmallest);
    }
}