public class Array_rotation {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        int rotationSteps = 5;

        System.out.println("Original Array:");
        printArray(array);

        rotateArrayRight(array, rotationSteps);

        System.out.println("Array after right rotation by " + rotationSteps + " steps:");
        printArray(array);
    }

    public static void rotateArrayRight(int[] array, int steps) {
        int length = array.length;
        steps = steps % length; // Ensure steps are within array length

        // Reverse the entire array
        reverseArray(array, 0, length - 1);

        // Reverse the first 'steps' elements
        reverseArray(array, 0, steps - 1);

        // Reverse the remaining elements
        reverseArray(array, steps, length - 1);
    }

    public static void reverseArray(int[] array, int start, int end) {
        while (start < end) {
            int temp = array[start];
            array[start] = array[end];
            array[end] = temp;
            start++;
            end--;
        }
    }

    public static void printArray(int[] array) {
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}