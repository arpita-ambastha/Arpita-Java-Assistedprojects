class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SortedCircularLinkedList {
    Node head;

    public SortedCircularLinkedList() {
        head = null;
    }

    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            newNode.next = newNode;
            head = newNode;
        } else if (data <= head.data) {
            Node last = getLastNode();
            newNode.next = head;
            head = newNode;
            last.next = head;
        } else {
            Node current = head;

            while (current.next != head && current.next.data < data) {
                current = current.next;
            }

            newNode.next = current.next;
            current.next = newNode;
        }
    }

    private Node getLastNode() {
        Node current = head;

        while (current.next != head) {
            current = current.next;
        }

        return current;
    }

    public void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;

        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);

        System.out.println();
    }
}

public class Circularlinkedlist {
    public static void main(String[] args) {
        SortedCircularLinkedList list = new SortedCircularLinkedList();
        list.insert(3);
        list.insert(7);
        list.insert(10);
        list.insert(5);

        System.out.println("Sorted Circular Linked List:");
        list.display();
    }
}
