public class LinkedList {
    private static class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            next = null;
        }
    }

    private Node head;

    private void deleteNode(int key) {
        if (head == null) {
            System.out.println("Linked list is empty.");
            return;
        }

        if (head.data == key) {
            head = head.next;
            System.out.println("Key found at the head node and deleted.");
            return;
        }

        Node prevNode = null;
        Node currNode = head;

        while (currNode != null && currNode.data != key) {
            prevNode = currNode;
            currNode = currNode.next;
        }

        if (currNode != null) {
            prevNode.next = currNode.next;
            System.out.println("Key found and deleted.");
        } else {
            System.out.println("Key not found in the linked list.");
        }
    }

    private void displayList() {
        Node currNode = head;
        if (currNode == null) {
            System.out.println("Linked list is empty.");
            return;
        }

        System.out.print("Linked list: ");
        while (currNode != null) {
            System.out.print(currNode.data + " ");
            currNode = currNode.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();

        linkedList.head = new Node(10);
        Node second = new Node(20);
        Node third = new Node(30);
        Node fourth = new Node(40);

        linkedList.head.next = second;
        second.next = third;
        third.next = fourth;

        linkedList.displayList();

        int key = 20;
        linkedList.deleteNode(key);

        linkedList.displayList();
    }
}