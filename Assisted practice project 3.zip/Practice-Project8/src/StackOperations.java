
import java.util.Stack;

public class StackOperations {
    public static void main(String[] args) {
        // Create a stack
        Stack<Integer> stack = new Stack<>();

        // Insert elements into the stack
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);

        // Print the stack
        System.out.println("Stack: " + stack);

        // Remove an element from the stack
        int removedElement = stack.pop();
        System.out.println("Removed element: " + removedElement);

        // Print the updated stack
        System.out.println("Stack after removal: " + stack);
    }
}
