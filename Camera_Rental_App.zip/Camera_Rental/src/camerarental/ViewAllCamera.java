package camerarental;
import java.util.ArrayList;

public class ViewAllCamera {

	private static final ArrayList<camera> list = null;

	public static void View(ArrayList<camera> list) {
	    int i = 1;
	    System.out.println("CamID\tBrand\t\tModel\t\tPrice(per day)\tStatus");
	    System.out.println("=============================================================");
	    for (camera c : list) {    
	        System.out.println(i + "\t" + c.CamName + "\t" + c.Model + "\t\t" + camera.Rent + "\t\tavailable");
	        i = i + 1;
	    }
	    }
	    public static void main(String[] args) {
	    ArrayList<camera> cameraList = new ArrayList<camera>();

	    // Add the provided camera list
	    cameraList.add(new camera("Samsung\t", "DS123", 500));
	    cameraList.add(new camera("Sony\t", "H0214", 500));
	    cameraList.add(new camera("Panasonic", "XC", 500));
	    cameraList.add(new camera("Canon\t", "XLR", 500));
	    cameraList.add(new camera("Fujitsu\t", "J5", 500));
	    cameraList.add(new camera("Sony\t", "HD226", 500));
	    cameraList.add(new camera("LG\t", "L123", 500));
	    cameraList.add(new camera("Canon\t", "XPL", 500));
	    cameraList.add(new camera("Sony\t", "DSLR-12", 500));
	    cameraList.add(new camera("Sony\t", "1234", 500));
	    cameraList.add(new camera("Canon\t", "5050", 500));
	    cameraList.add(new camera("NIKON\t", "2030", 500));
	    cameraList.add(new camera("Chroma\t", "CT", 500));
	    cameraList.add(new camera("Canon\t", "Digital", 123));
	    cameraList.add(new camera("Samsung\t", "SM123", 200));
	    
	    }
	    
	    {

		loginpage.Menu(list);
	    }
	}
	    
