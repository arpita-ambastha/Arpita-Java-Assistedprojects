package camerarental;

public class camera {

	
		public static int getRent() {
			return Rent;
		}
		public void setRent(int rent) {
			Rent = rent;
		}
		/// class variables
		String CamName;
		String Model;
		 static int Rent;
		
		// Constructor to set state to instance object
		camera(String CamName,String Model,int Rent) 
		{
			this.CamName =CamName;
			this.Model = Model;
			camera.Rent = Rent;
			
		}
		// can write methods
		void Display() {
			System.out.println(CamName+" "+"Added");
		}
	}
