package camerarental;

	import java.util.ArrayList;
	import java.util.Scanner;

	public class MyCamera {
		
			@SuppressWarnings("static-access")
			public static void MyCam(ArrayList<camera> list) {
			//Creating empty array list of objects of data type camera
			//ArrayList<Camera> list=new ArrayList<Camera>();
			// variables and functions required
			int MyCamChoice;
			Scanner sc = new Scanner(System.in);
			do {
			//shows options
			System.out.println("\n1.ADD\n2.REMOVE\n3.VIEW MY CAMERAS\n4.GO TO PREVIOUS MENU\n");
			// accepts choice
			MyCamChoice = sc.nextInt();
			// switch according to choice
			switch (MyCamChoice) {
			case 1:
				// Asking details required
				System.out.println("Enter the camera brand\n");
				String brand = sc.next();
				System.out.println("Enter the model\n");
				String model = sc.next();
				System.out.println("Enter the per day price\n");
				int price =sc.nextInt();
				// need to call a method to add new camera
				list.add(new camera(brand,model,price));
				System.out.println("YOUR CAMERA HAS BEEN SUCCESSFULLY ADDED TO THE LIST.");
				break;
				
				
			case 2:
				int i=1;
				System.out.println("CamID\tBrand\t\tModel\tPrice(per day)\tStatus");
				System.out.println("=============================================================");
				for(camera c : list) {	
				System.out.println(i+"\t"+c.CamName+"\t\t"+c.Model+"\t"+c.Rent+"\t\tAvailable");
					i=i+1;
				}
				System.out.println("Enter the cameraID\n");
				int opt = sc.nextInt();
				 if (opt >= 1 && opt <= list.size()) {
				        list.remove(opt - 1);
				        System.out.println("Camera successfully removed from the list.");
				    } else {
				        System.out.println("Invalid camera ID.");
				    }
				 break;
			case 3:
				i=1;
				System.out.println("CamID\tBrand\t\tModel\t\tPrice(per day)\tStatus");
				System.out.println("=============================================================");
				for(camera c : list) {	
				System.out.println(i+"\t"+c.CamName+"\t\t"+c.Model+"\t\t"+c.Rent+"\t\tAvailable");
					i=i+1;
				}
				break;
			case 4:
				loginpage.Menu(list);
				break;
			default:
				throw new IllegalArgumentException("Unexpected value: " + MyCamChoice);
			}}
			while(true);
			
		}
		
		public static void main(String[] args) {
			
			//MyCam();
			ArrayList<camera> cameraList = new ArrayList<camera>();

	        // Add the provided camera list
			cameraList.add(new camera("Samsung", "DS123", 500));
		    cameraList.add(new camera("Sony", "H0214", 500));
		    cameraList.add(new camera("Canon", "XLR", 500));
		    cameraList.add(new camera("Fujitsu", "J5", 500));
		    cameraList.add(new camera("Sony", "HD226", 500));
		    cameraList.add(new camera("LG", "L123", 500));
		    cameraList.add(new camera("Canon", "XPL", 500));
		    cameraList.add(new camera("Sony", "DSLR-12", 500));
		    cameraList.add(new camera("Sony", "1234", 500));
		    cameraList.add(new camera("Canon", "5050", 500));
		    cameraList.add(new camera("NIKON", "2030", 500));
		    cameraList.add(new camera("Chroma", "CT", 500));
		    cameraList.add(new camera("Canon", "Digital", 500));
		    cameraList.add(new camera("Samsung", "SM123", 500));
		    
		    
	        

	        MyCam(cameraList);
			
			
		}
		
		
		
		
		
		
	}


