package camerarental;

	import java.util.ArrayList;
	import java.util.Scanner;

	public class loginpage {
	    private static final String USERNAME = "arpita";
	    private static final String PASSWORD = "password";

	    public static void main(String[] args) {
	        ArrayList<camera> list = new ArrayList<>();

	        System.out.println("+--------------------------------------+");
	        System.out.println("| WELCOME TO CAMERA RENTAL APPLICATION |");
	        System.out.println("+--------------------------------------+");

	        Scanner sc = new Scanner(System.in);
	        System.out.println("Enter Username: ");
	        String userId = sc.next();

	        System.out.println("Enter Password: ");
	        String password = sc.next();

	        if (userId.equals(USERNAME) && password.equals(PASSWORD)) {
	            Menu(list);
	        } else {
	            System.out.println("Incorrect Username or Password. Try Again..!");
	        }
	    }

	    // Main Menu
	    public static void Menu(ArrayList<camera> list) {
	        int choice;
	        Scanner sc = new Scanner(System.in);
	        System.out.println("\n1.MY CAMERA\n2.RENT A CAMERA\n3.VIEW ALL CAMERAS\n4.MY WALLET\n5.EXIT\n");
	        System.out.println("\nEnter your choice:");
	        choice = sc.nextInt();

	        switch (choice) {
	            case 1:
	                // call MyCam method which handles all operations related to camera
	                MyCamera.MyCam(list);
	                break;
	            case 2:
	                // renting module
	                RentAcamera.Rent(list);
	                break;
	            case 3:
	                // view module
	                ViewAllCamera.View(list);
	                break;
	            case 4:
	                // This method will handle all operations related to Wallet
	                MyWallet.Wallet(list);
	                break;
	            case 5:
	                System.out.println("Exit");
	                break;
	            default:
	                throw new IllegalArgumentException("Incorrect choice: " + choice);
	        }
	    }
	}
