

import java.sql.*;

public class JdbcExample {
    public static void main(String[] args) {
        Connection connection = null;
        CallableStatement callableStatement = null;

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Set up the connection parameters
            String databaseURL = "jdbc:mysql://localhost:3306/Student";
            String username = "your_username";
            String password = "your_password";

            // Establish the connection
            connection = DriverManager.getConnection(databaseURL, username, password);

            // Prepare the stored procedure call
            String storedProcedure = "{CALL get_employee_details(?, ?)}";
            callableStatement = connection.prepareCall(storedProcedure);

            // Set input parameters
            int employeeId = 1;
            callableStatement.setInt(1, employeeId);

            // Register output parameters
            callableStatement.registerOutParameter(2, Types.VARCHAR);

            // Execute the stored procedure
            callableStatement.execute();

            // Retrieve the output parameter value
            String employeeName = callableStatement.getString(2);
            System.out.println("Employee Name: " + employeeName);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close JDBC objects
            try {
                if (callableStatement != null)
                    callableStatement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
