import java.sql.*;

public class JdbcExample {
    public static void main(String[] args) {
        Connection connection = null;
        Statement statement = null;

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Set up the connection parameters
            String databaseURL = "jdbc:mysql://localhost:3306/Student";
            String username = "your_username";
            String password = "your_password";

            // Establish the connection
            connection = DriverManager.getConnection(databaseURL, username, password);

            // Create a Statement
            statement = connection.createStatement();

            // Insert a record
            String insertSQL = "INSERT INTO employees (id, name, age) VALUES (1, 'John Doe', 30)";
            statement.executeUpdate(insertSQL);
            System.out.println("Record inserted successfully.");

            // Update a record
            String updateSQL = "UPDATE employees SET age = 35 WHERE id = 1";
            statement.executeUpdate(updateSQL);
            System.out.println("Record updated successfully.");

            // Delete a record
            String deleteSQL = "DELETE FROM employees WHERE id = 1";
            statement.executeUpdate(deleteSQL);
            System.out.println("Record deleted successfully.");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close JDBC objects
            try {
                if (statement != null)
                    statement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}

