import java.sql.*;

public class JdbcExample {
    public static void main(String[] args) {
        Connection connection = null;
        Statement statement = null;

        try {
            // Load the JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Set up the connection parameters
            String databaseURL = "jdbc:mysql://localhost:3306/ Student";
            String username = "your_username";
            String password = "your_password";

            // Establish the connection
            connection = DriverManager.getConnection(databaseURL, username, password);

            // Create a Statement
            statement = connection.createStatement();

            // Create a database
            String createDatabaseSQL = "CREATE DATABASE mydatabase";
            statement.executeUpdate(createDatabaseSQL);
            System.out.println("Database created successfully.");

            // Select the newly created database
            String useDatabaseSQL = "USE mydatabase";
            statement.executeUpdate(useDatabaseSQL);
            System.out.println("Database selected successfully.");

            // Drop the database
            String dropDatabaseSQL = "DROP DATABASE mydatabase";
            statement.executeUpdate(dropDatabaseSQL);
            System.out.println("Database dropped successfully.");
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } finally {
            // Close JDBC objects
            try {
                if (statement != null)
                    statement.close();
                if (connection != null)
                    connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
