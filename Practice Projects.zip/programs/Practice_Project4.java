public class Practice_Project4 {

  int a;
  boolean b;
  String languages;
   Practice_Project4() {
    a = 0;
    b = false;
  }

  // Practice_Project4 accepting single value
  Practice_Project4(String lang) {
    languages = lang;
    System.out.println(languages + " Programming Language");
  }

  public static void main(String[] args) {

    // A default Practice_Project4 is called
    Practice_Project4 obj = new Practice_Project4();

    System.out.println("Default Value:");
    System.out.println("a = " + obj.a);
    System.out.println("b = " + obj.b);

    // call Practice_Project4 by passing a single value
    Practice_Project4 obj1 = new Practice_Project4("Java");
    Practice_Project4 obj2 = new Practice_Project4("Python");
    Practice_Project4 obj3 = new Practice_Project4("C");
  }
} 
