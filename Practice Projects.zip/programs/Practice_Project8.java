public class Practice_Project8
 {
    public static void main(String args[]) {
      // Given String 
      String str = "Alive is Awesome";
      // Converting String to StringBuffer using constructor
      StringBuffer sb1 = new StringBuffer(str);
      // Printing StringBuffer object
      System.out.println("Converted String to StringBuffer: " + sb1);

StringBuilder sb2 = new StringBuilder(str);
      // Printing StringBuilder object
      System.out.println("Converted String to StringBuffer:"+sb2);
    }
}

