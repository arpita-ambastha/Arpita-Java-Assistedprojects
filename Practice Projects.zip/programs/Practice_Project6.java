
import java.util.HashMap;

// Main class
// To add elements to HashMap
class AddElementsToHashMap {

	// Main driver method
	public static void main(String args[])
	{
		
		HashMap<Integer, String> hm1 = new HashMap<>(10);


		

		// HashMap 1
		hm1.put(1, "one");
		hm1.put(2, "two");
		hm1.put(3, "three");

	
		boolean result = hm1.isEmpty();  
		if (result==true)
        System.out.println("hashmap is not used ");
		else
		System.out.println("hashmap is used ");


		// Printing elements of HashMap 1
		System.out.println("Mappings of HashMap hm1 are : "
						+ hm1);

		
	}
}
