
    import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;

public class ps10 {
  public static void main(String[] args) {
Scanner myObj = new Scanner(System.in);
System.out.println("Enter two words");

    String word1 = myObj.nextLine();
    String word2 = myObj.nextLine();
    Pattern pattern = Pattern.compile(word1, Pattern.CASE_INSENSITIVE);
    Matcher matcher = pattern.matcher(word2);
    boolean matchFound = matcher.find();
    if(matchFound) {
      System.out.println("Match found");
    } else {
      System.out.println("Match not found");
    }
  }
}

