
import java.io.*;
public class callmethods
{
    class one {
 
    // Method one
    // Method of this class
    void hello()
    {
        // Print statement whenever this method s called
        System.out.println("This is the userDefinedMethod");
    }
 
    // Method 2
    // Main driver method
    public static void main(String[] args)
    {
        // Creating instance of the class
        // inside the main() method
     one ob = new one();
 
        // Calling the method of class one
        // inside class 2
        ob.hello();
    }
}

// Class 1
abstract class twohelp {

	// Creating abstract method
	abstract void check(String name);
}

// Class 2

public class two extends twohelp {

	// main driver method
	public static void main(String[] args)
	{
		// Creating the instance of the class
		two ob = new two();

		// Accessing the abstract method
		ob.check("two");
	}

	// Extends the abstract method
	@Override void check(String name)
	{
		System.out.println(name);
	}
}


// Main class
public class three {

	// Main driver method
	public static void main(String[] args)
	{
		// Creating object of the class in
		// main() method
		three ob = new three();

		// Print the hashcode using
		// predefined hashCode() method
		System.out.println(ob.hashCode());
	}
}


// Main class
class four {

	// Method 1
	// Static method
	static void hello()
	{

		// Print statement
		System.out.println("Hello");
	}

	// Method 2
	// Main driver method
	public static void main(String[] args)
	{

		// calling the Method 1
		// Accessing method
		hello();
	}
}
}