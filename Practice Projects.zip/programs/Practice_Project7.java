class Practice_Project7{
private class Inner_Demo{
public void print() {
System.out.println("This is an inner class");
 }
}
void display_Inner(){
Inner_Demo inClass = new Inner_Demo();
inClass.print();
 }
}
class Inner_Classes {
public static void main(String args[]) {
// Instantiating the outer class
Practice_Project7 outClass = new Practice_Project7();

// Accessing the display_Inner() method.
outClass.display_Inner();
 }
}