public class Practice_Project2{
class A
{ 
    private void display()
    { 
        System.out.println("default acces modifiers"); 
    }

public void display2() 
    { 
        System.out.println("public acces modifiers"); 
    } 

protected void display3() 
    { 
        System.out.println("private access modifiers"); 
    } 
} 
 class B{
public static void main(String args[]) 
    { 
        Practice_Project2 d=new Practice_Project2();
        A obj =d. new A(); 
        // Trying to access private method
        // of another class 
        obj.display(); 
        obj.display2(); 
        obj.display3(); 
    } 
 }
  
} 
      