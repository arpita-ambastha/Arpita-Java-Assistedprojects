public class Person {
    private String name;
    private List<String> addresses;
    private Set<String> emails;
    private Map<String, String> phoneNumbers;

    // Constructor, getters, setters, etc.
}
