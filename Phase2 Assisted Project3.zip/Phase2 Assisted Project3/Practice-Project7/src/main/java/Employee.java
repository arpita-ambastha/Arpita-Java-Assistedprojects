
@Entity
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Embedded
    private ContactInfo contactInfo;

    // Constructors, getters, setters, etc.
}

@Embeddable
public class ContactInfo {
    private String address;
    private String phoneNumber;
    private String email;

    // Constructors, getters, setters, etc.

Employee employee = new Employee();
employee.setName("John Doe");

ContactInfo contactInfo = new ContactInfo();
contactInfo.setAddress("123 Main St");
contactInfo.setPhoneNumber("555-1234");
contactInfo.setEmail("john.doe@example.com");

employee.setContactInfo(contactInfo);

session.save(employee);
Employee employee = session.get(Employee.class, employeeId);

String address = employee.getContactInfo().getAddress();
String phoneNumber = employee.getContactInfo().getPhoneNumber();
String email = employee.getContactInfo().getEmail();
}


