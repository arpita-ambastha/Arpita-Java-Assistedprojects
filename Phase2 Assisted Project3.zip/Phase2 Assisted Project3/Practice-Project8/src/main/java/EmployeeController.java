
		@RestController
		@RequestMapping("/employees")
		public class EmployeeController {

		    @Autowired
		    private EmployeeService employeeService;

		    @PostMapping
		    public void saveEmployee(@RequestBody Employee employee) {
		        employeeService.saveEmployee(employee);
		    }

		    @GetMapping
		    public List<Employee> getAllEmployees() {
		        return employeeService.getAllEmployees();
		    }
		}

		// TODO Auto-generated method stub


}
