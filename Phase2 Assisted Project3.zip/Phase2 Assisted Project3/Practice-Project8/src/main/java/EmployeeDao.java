
		public class EmployeeDAO {

		    @Autowired
		    private SessionFactory sessionFactory;

		    public void save(Employee employee) {
		        Session session = sessionFactory.getCurrentSession();
		        session.save(employee);
		    }

		    public List<Employee> getAllEmployees() {
		        Session session = sessionFactory.getCurrentSession();
		        CriteriaQuery<Employee> criteriaQuery = session.getCriteriaBuilder().createQuery(Employee.class);
		        criteriaQuery.from(Employee.class);
		        return session.createQuery(criteriaQuery).getResultList();
		    }
		}

	}

}
