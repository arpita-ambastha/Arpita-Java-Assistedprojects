
		@Service
		public class Service {

		    @Autowired
		    private EmployeeDAO employeeDAO;

		    @Transactional
		    public void saveEmployee(Employee employee) {
		        employeeDAO.save(employee);
		    }

		    public List<Employee> getAllEmployees() {
		        return employeeDAO.getAllEmployees();
		    }
		}

	}

}
