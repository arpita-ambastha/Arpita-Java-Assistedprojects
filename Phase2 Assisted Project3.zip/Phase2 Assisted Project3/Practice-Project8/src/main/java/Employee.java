
public class Employee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		@Entity
		@Table(name = "employee")
		public class Employee {
		    @Id
		    @GeneratedValue(strategy = GenerationType.IDENTITY)
		    private Long id;

		    private String name;

		    // Constructors, getters, setters, etc.
		}

	}

}
