package com.tut;


import org.hibernate.SessionFactory;

public class App {
	public static void main (String[]args) {
		System.out.println("Project started..");
		
		Configuration cfg = new Configuration();
		cfg.getAppConfigurationEntry(("hibernate.cfg.xml");
		SessionFactory factory = cfg.buildSessionFactory();
		
		//creating Student
		Student st=new Student();
		st.setId(101);
		st.setName("John");
		st.setCity("Delhi");
		System.out.println(st);
		
		Session session = factory.getCurrentSession();
		///
		session.beginTransaction();
		session.save(st);
		
		tx.commit();
		session.close();
		
		
		
		
		System.out.println(factory);
		System.out.println(factory.isClosed());
	}

}
