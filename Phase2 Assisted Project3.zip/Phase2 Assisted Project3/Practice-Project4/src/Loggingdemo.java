import org.apache.logging.log4j.*;

public class Loggingdemo {
	
	private static Logger demologger = LogManager.getLogger(LoggingDemo.class.getName());
	public static void main (String[] args) {
		System.out.println("This is syso");
		demoLogger.info("Click successful");
		demoLogger.error("DB Connectioon Failed");
		demoLogger.debug("This is debug");
	}

}
